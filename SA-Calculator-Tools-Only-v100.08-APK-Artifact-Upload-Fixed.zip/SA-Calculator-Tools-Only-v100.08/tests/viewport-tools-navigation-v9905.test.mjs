import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8')+'\n'+fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
test('head contains no stray rendered text before the app shell',()=>{
 const head=html.match(/<head>([\s\S]*?)<\/head>/i)?.[1]||'';
 assert.doesNotMatch(head,/>\s*Base application styles\s*</i);
 assert.ok(!html.includes('> Base application styles. <'));
});
test('Tools has a visible primary navigation destination wired to tools screen',()=>{
 assert.match(html,/<button[^>]*data-bottom-nav="tools"[^>]*>[\s\S]*?<span>Tools<\/span>/);
 assert.match(html,/<section[^>]*id="screen-tools"/);
 const js=fs.readFileSync('assets/js/app.js','utf8');
 assert.match(js,/if\s*\(target\s*===\s*'tools'\)\s*\{\s*switchScreen\('tools'\)/);
});
test('Android viewport shell cannot be displaced by anonymous flex content',()=>{
 assert.match(css,/body\s*\{\s*display:flex;\s*justify-content:center;\s*align-items:stretch;/);
 assert.match(css,/#app-container\s*\{[^}]*max-width:520px[^}]*min-width:0/s);
 assert.match(css,/#tool-keypad-dock > \.tool-keypad-grid \{[^}]*grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
});
