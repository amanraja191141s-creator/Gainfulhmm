# Release v100.08 — APK artifact path fix

- Version: `2.0.6-v100.08`; Android versionCode: `1099147`.
- Fixed GitHub Actions artifact upload after successful APK build.
- The project ZIP is extracted under `RUNNER_TEMP`, while `upload-artifact` resolves relative paths from `GITHUB_WORKSPACE`; the previous relative path therefore pointed to the wrong directory.
- The workflow now exports and uploads the verified absolute APK path (`APK_PATH`) and performs a pre-upload existence check.
- Preserves ZIP auto-extraction, project-root detection, Android SDK setup, and the 12-tools-only app.
